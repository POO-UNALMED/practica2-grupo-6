# 🦾 Practica 1  _CompuElectronics 🎮💻_

 
## INTEGRANTES
#### Deyner
#### Daniel
#### Deninson Alexander Chamorro Rueda
![x](https://cdn.nextgov.com/media/img/upload/2020/08/04/NGrecords20200804/860x394.jpg)
